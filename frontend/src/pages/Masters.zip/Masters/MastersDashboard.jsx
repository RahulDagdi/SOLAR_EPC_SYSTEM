import { Link } from "react-router-dom";

const masters = [

    {
        name: "Country",
        path: "/masters/countries"
    },

    {
        name: "State",
        path: "/masters/states"
    },

    {
        name: "District",
        path: "/masters/districts"
    },

    {
        name: "City",
        path: "/masters/cities"
    },

    {
        name: "Currency",
        path: "/masters/currencies"
    },

    {
        name: "Customer Type",
        path: "/masters/customer-types"
    },

    {
        name: "Industry Segment",
        path: "/masters/industry-segments"
    },

    {
        name: "MSME Status",
        path: "/masters/msme-status"
    },

    {
        name: "Customer Status",
        path: "/masters/customer-status"
    }

];

const MastersDashboard = () => {

    return (

        <div className="p-6">

            <h1 className="text-3xl font-bold mb-8">

                Masters

            </h1>

            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-5">

                {

                    masters.map((item)=>(

                        <Link

                            key={item.name}

                            to={item.path}

                            className="border rounded-xl shadow hover:shadow-lg transition p-6 bg-white"

                        >

                            <h2 className="text-lg font-semibold">

                                {item.name}

                            </h2>

                        </Link>

                    ))

                }

            </div>

        </div>

    );

};

export default MastersDashboard;