import MasterPage from "./MasterPage";

const CityMaster = () => {

    return (

        <MasterPage

            title="City Master"

            api="/masters/cities"

            columns={[

                {
                    title: "City",
                    key: "name"
                },

                {
                    title: "City Code",
                    key: "cityCode"
                }

            ]}

            fields={[

                {
                    name: "name",
                    label: "City Name"
                },

                {
                    name: "cityCode",
                    label: "City Code"
                }

            ]}

        />

    );

};

export default CityMaster;