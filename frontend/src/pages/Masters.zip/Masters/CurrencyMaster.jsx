import MasterPage from "./MasterPage";

const CurrencyMaster=()=>{

return(

<MasterPage

title="Currency Master"

api="/masters/currencies"

columns={[

{

title:"Currency",

key:"currencyName"

},

{

title:"Code",

key:"currencyCode"

},

{

title:"Symbol",

key:"currencySymbol"

}

]}

fields={[

{

name:"currencyName",

label:"Currency"

},

{

name:"currencyCode",

label:"Currency Code"

},

{

name:"currencySymbol",

label:"Symbol"

}

]}

/>

)

}

export default CurrencyMaster;